import React from 'react';
import styled from '@emotion/styled';
import { MediaQuery } from '@/shared/styles';

export const CalendarContainer = styled.div<React.CSSProperties>`
  display: grid;
  width: 100%;
  height: 100%;
  box-sizing:border-box;
  box-shadow: 1px 1px 0 inset #e9e9e9;
  grid-template-columns: repeat( auto-fill, 14.2857% );
  grid-auto-rows:36px 1fr 1fr 1fr 1fr 1fr 1fr;
  ${MediaQuery.mobile} {
    display:flex;
    overflow-x:auto;
    padding-bottom: 10px;
    box-shadow: 0 1px 0 inset #e9e9e9;
  }
  & > div {
    display: flex;
    flex-direction:column;
    box-sizing:border-box;
    box-shadow: -1px -1px 0 inset #e9e9e9;
    &.dayname {
      display:flex;
      align-items:center;
      justify-content:center;
      text-align:center;
      font-weight: 500;
      height: 36px;
      flex-shrink:0;
      flex-grow:0;
      flex-basis: 36px;
      ${MediaQuery.mobile} {
        display:none;
      }
    }
    &:nth-of-type(7n-7) {
      color: blue;
    }
    &:nth-of-type(7n -6) {
      color: red;
    }
    &.day {
      position: relative;
      box-sizing:border-box;
      padding: 5px;
      ${MediaQuery.mobile} {
        min-height: 70px;
        &.first {
          box-shadow: 0 0 0 1px inset #e9e9e9;
        }
      }
      & > * {
        pointer-events: none;
      }
      & > span {
        margin: -3px;
        display: inline-flex;
        width: 30px;
        height: 30px;
        border-radius: 30px;
        padding: 3px;
        align-items:center;
        justify-content:center;
        & > i {
          font-size:8px;
          font-style:normal;
          display: none;
          ${MediaQuery.mobile} {
            display:unset;
          }
        }
      }
      & > ul {
        margin-top:5px;
        font-size: 13px;
        color: rgba(0,0,0,0.8);
        overflow: hidden;
        ${MediaQuery.mobile} {
          display:none;
        }
        @media screen and (max-height: 768px) {
          display:none;
        }
        & > li {
          height: 15px;
          overflow: hidden;
          text-overflow:ellipsis;
          white-space:pre;
          &.done {
            text-decoration: line-through;
          }
        }
      }
      & > div.stat {
        position: absolute;
        padding: 8px;
        right: 2px;
        bottom: 2px;
        font-size: 10px;
        backdrop-filter: blur(3px);
        border-radius:6px;
        
      }
      &.today {
        ${MediaQuery.mobile} {
          background-color: rgb(102, 49, 153);
          & > div.stat {
            color: #ffffff;
          }
        }
        span {
          background-color: rgb(102, 49, 153);
          color: white;
        }
      }
      &:not(.is-day-of-month) {
        color: rgba(0,0,0,0.4);
        ${MediaQuery.mobile} {
          display:none;
        }
        & > div {
          opacity: 0.4;
        }
      }
    }
    
    & > div {
      color: unset;
      flex: 1;
      margin-top: 5px; 
    }
  }
`;
