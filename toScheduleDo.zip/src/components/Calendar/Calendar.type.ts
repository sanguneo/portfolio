import dayjs from 'dayjs';

export interface IDay {
  date: dayjs.Dayjs | null;
  isDayOfMonth: boolean;
}
