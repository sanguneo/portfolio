import React, { SyntheticEvent, useEffect, useRef } from 'react';
import { IDay } from './Calendar.type';
import { daynames } from './Calendar.constants';
import { CalendarContainer } from './Calendar.styles';
import classnames from 'classnames';
import dayjs from 'dayjs';
import { useScheduleStore } from '@/stores/useScheduleStore';
import { getScheduleState } from '@/shared/constants/pages';
import { useControlStore } from '@/stores/useControlStore';

const Calendar = (): React.ReactElement => {
  const { date, setDate } = useControlStore(store => ({ date: store.date, setDate: store.setDate }));
  const schedule = useScheduleStore(getScheduleState);

  const startTime = date.startOf('month'); // 이번달 첫날
  const endTime = date.endOf('month'); // 이번달 마지막날

  const prevMonth = startTime.clone().subtract(1, 'day'); // 이전달 마지막날
  const nextMonth = endTime.clone().add(1, 'day'); // 다음달 첫날

  const days: IDay[] = [
  ...Array.from({length: startTime.day()}, (_, i) => ({ date: prevMonth.subtract(i, 'day'), isDayOfMonth: false })).reverse() as IDay[],
  ...Array.from({length: endTime.date()}, (_, i) => ({ date: date.date(i + 1), isDayOfMonth: true })) as IDay[]
  ]
  days.push(...Array.from({length: 7 - (days.length % 7)}, (_, i) => ({ date: nextMonth.add(i, 'day'), isDayOfMonth: false })) as IDay[])
  // 캘린더 생성


  const setDateHelper = (e: SyntheticEvent) => {
    e.stopPropagation();
    if (!(e.target as HTMLDivElement).dataset.date) return;
    setDate(dayjs((e.target as HTMLDivElement).dataset.date));
  }

  const getScheduleOnDate = (date: dayjs.Dayjs) => {
    return schedule.filter((scheduleItem) => date.isSame(scheduleItem.date, 'day'));
  }
  useEffect(()=> {
    document.querySelector('.today').scrollIntoView({behavior: 'smooth'});
  }, []);

  return (
    <CalendarContainer onClick={setDateHelper}>
      {daynames.map((dayname: string, i) => <div key={dayname}className="dayname">{dayname}</div>)}
      <>
        {days.map((d: IDay, i: number) => {
          const scheduleOnDay = getScheduleOnDate(d.date);
          return <div key={i} className={classnames('day', { 'is-day-of-month': d.isDayOfMonth, today: d.date.isSame(date), first: i === 0 })}
               data-date={d.date.toISOString()}>
            <span>{d.date.date()}<i>{daynames[d.date.day()]}</i></span>
            <ul>
              {scheduleOnDay.slice(0, 3).map((item, idx) => <li key={item.date.toString + '_' + idx} className={classnames({done: item.status})}>- {item.subject}</li>)}
            </ul>
            {scheduleOnDay.length ? <div className="stat">{scheduleOnDay.filter(item=>item.status).length || 0}/{scheduleOnDay.length}</div> : null}
          </div>
        })}
      </>
    </CalendarContainer>
  );
};

export default Calendar;
