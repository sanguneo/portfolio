import React from 'react';
import dayjs from 'dayjs';
import { IMoveDate } from './Indicator.type';
import { IndicatorContainer } from './Indicator.styles';
import { useControlStore } from '@/stores/useControlStore';

const Indicator = (): React.ReactElement => {
  const { date, setDate } = useControlStore(store => ({ date: store.date, setDate: store.setDate }));
  const dateString = date.format('YYYY-MM-DD');
  const moveDate: IMoveDate = (direction, type) => {
    if (direction === 'next') {
      setDate(dayjs(date).add(1, type));
    } else {
      setDate(dayjs(date).subtract(1, type));
    }
  }
  return (
    <IndicatorContainer>
      <button onClick={()=>moveDate('prev', 'month')}>〈〈</button>
      <button onClick={()=>moveDate('prev', 'day')}>〈</button>
      <span>{dateString}</span>
      <button onClick={()=>moveDate('next', 'day')}>〉</button>
      <button onClick={()=>moveDate('next', 'month')}>〉〉</button>
    </IndicatorContainer>
  );
};

export default Indicator;
