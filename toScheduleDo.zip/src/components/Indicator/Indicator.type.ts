import dayjs from "dayjs";

export type IMoveDate = (direction: 'prev' | 'next', type: 'day' | 'month') => void

export interface IIndicator {
  date: dayjs.Dayjs;
  moveDate: IMoveDate;
}
