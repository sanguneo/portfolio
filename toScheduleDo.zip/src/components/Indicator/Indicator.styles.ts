import React from 'react';
import styled from '@emotion/styled';
import { MediaQuery } from '@/shared/styles';

export const IndicatorContainer = styled.div<React.CSSProperties>`
  display:flex;
  align-items:center;
  gap: 15px;
  @media screen and (max-width: 1100px) and (min-width: 800px) {
    gap: 10px;
  }
  & > span {
    font-size: 36px;
    font-weight:500;
    margin: 0 20px;
    @media screen and (max-width: 1100px) and (min-width: 800px) {
      font-size: 20px;
      margin: 0;
    }
    @media screen and (max-width: 600px) {
      font-size: 20px;
      margin: 0;
    }
  }
  & > button {
    width: 50px;
    height: 36px;
    background-color: #f0f0f0;
    opacity: 0.5;
    &:hover {
      opacity: 1;
    }
  }
`;
