import React, { useEffect, useMemo, useState } from 'react';
import classnames from 'classnames';
import dayjs from 'dayjs';
import TodoItem from '../TodoItem/TodoItem';
import { ISchedule, useScheduleStore } from '@/stores/useScheduleStore';
import { useControlStore } from '@/stores/useControlStore';
import { getScheduleState, manipulateScheduleState, setCheckedListState, setIdxOnDateState } from '@/shared/constants/pages';
import { TodoListContainer } from './TodoList.styles';
import { ReactComponent as Add } from '@/assets/add.svg';

const TodoList = (): React.ReactElement => {
  const [draft, setDraft] = useState<ISchedule | null>(null);
  const { date } = useControlStore(store => ({ date: store.date }))
  const schedule = useScheduleStore(getScheduleState);
  const { addSchedule, removeSchedule, editSchedule } = useScheduleStore(manipulateScheduleState);
  const setIdxOnDate = useControlStore(setIdxOnDateState)
  const setCheckedList = useControlStore(setCheckedListState);
  const scheduleOnDay = useMemo(()=> schedule.filter((item) => dayjs(item.date).isSame(date, 'day')).sort((a, b) => dayjs(a.date).isBefore(dayjs(b.date)) ? -1 : 1), [date, schedule]);
  const addScheduleDraft = () => {
    if (draft) return;
    const dateOnDraft = dayjs(date).toISOString();
    setDraft({
      date: dateOnDraft,
      subject: '',
      status: false,
    })
  }
  const submit = (idx?: number, scheduleItem?: ISchedule) => {
    if (!scheduleItem) {
      addSchedule(draft);
      setDraft(null);
      return;
    }
  }

  const setSchedule = (scheduleItem: ISchedule, idx?: number) => {
    if (idx === undefined) {
      if (scheduleItem) setDraft(scheduleItem);
      else setDraft(null);
      return;
    }
    if (scheduleItem) editSchedule(idx, scheduleItem);
    else removeSchedule(idx);

  }

  useEffect(() => {
    setIdxOnDate(scheduleOnDay.map(schedule => schedule.idx));
  }, [scheduleOnDay]);

  useEffect(() => {
    setDraft(null);
    setCheckedList([]);
  }, [date]);

  return (
    <TodoListContainer className={classnames({'no-schedules-container': scheduleOnDay.length === 0 && !draft})}>
      {scheduleOnDay.length === 0 && !draft
        ? <li className="no-schedules">스케쥴이 없습니다. 아래 버튼을 눌러 추가해주세요</li>
        : scheduleOnDay.map(scheduleItem => <TodoItem key={date + '_' + scheduleItem.idx} date={date} schedule={scheduleItem} setSchedule={setSchedule} submit={submit} idx={scheduleItem.idx}/>)}
      {draft ? <TodoItem date={date} schedule={draft} setSchedule={setSchedule} submit={submit}/> : null}
      <li className='add-icon-wrapper'>
        <Add onClick={addScheduleDraft}/>
      </li>
    </TodoListContainer>
  );
};

export default TodoList;
