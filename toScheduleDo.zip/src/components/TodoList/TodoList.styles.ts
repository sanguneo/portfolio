import React from 'react';
import styled from '@emotion/styled';

export const TodoListContainer = styled.ul<React.CSSProperties>`
  width: 100%;
  height: 100%;
  overflow-y: overlay;
  overflow-y: auto;
  display:flex;
  align-items:center;
  justify-content:flex-start;
  flex-direction: column;
  gap: 16px;
  &.no-schedules-container {
    justify-content:center;  
  }
  & > li.no-schedules {
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:14px;
    color: #888888;
    & + li.add-icon-wrapper {
       & > svg {
        width: 128px!important;
        height: 128px!important;
       }
    }
  }
  & > li.add-icon-wrapper {
    display:flex;
    align-items:center;
    justify-content:center;
    & > svg {
      width: 32px;
      height: 32px;
      opacity: 0.5;
      cursor: pointer;
      &:hover {
        opacity: 1;
      }
      
    }
  }
`;
