import React from 'react';
import styled from '@emotion/styled';
import Edit from '@/assets/edit.svg';
import Strike from '@/assets/strike.svg';

export const TodoControlContainer = styled.div<React.CSSProperties>`
  display: flex;
  width: calc(100% + 5px);
  justify-content:flex-end;
  align-items:center;
  margin-right: -5px;
  label[for=allCheck] {
    font-size:14px;
    transform: translateY(0.5px);
    margin-left:10px;
  }
  & > button {
    position: relative;
    width: 32px;
    height: 32px;
    border-radius: 14px;
    margin-left: auto;
    margin-right:2px;
    &:hover {
      background-color: rgba(0,0,0, 0.05);
    }
    &:before, &:after {
      content: '';
      position: absolute;
      top: 2px;
      width: 28px;
      height: 28px;
      display:block;
      background-image: url("${Strike}");
      background-size: 24px;
      background-repeat:no-repeat;
    }
    &:before {
      background-position:0 center;
    }
    &:after {
      background-position:10px center;
    }
  }
  & > label.edit {
    cursor: pointer;
    & > i {
      display:flex;
      align-items:center;
      justify-content:center;
      width: 32px;
      height: 32px;
      border-radius: 14px;
      background-image: url("${Edit}");
      background-size: 24px;
      background-position:center;
      background-repeat:no-repeat;
    }
    & > input[type=checkbox]:checked {
      & + i {
        background-color: rgba(0,0,0, 0.2) !important;
      }
    }
    &:hover {
      & > i {
        background-color: rgba(0,0,0, 0.05);
      }
    }
  }
`;
