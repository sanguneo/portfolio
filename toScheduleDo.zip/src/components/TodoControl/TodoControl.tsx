import React, { SyntheticEvent } from 'react';
import { TodoControlContainer } from './TodoControl.styles';
import { useControlStore } from '@/stores/useControlStore';
import { useScheduleStore } from '@/stores/useScheduleStore';
import {
  checkedListState,
  getScheduleState,
  getToggleEditMode,
  idxOnDateState,
  setCheckedListState, setScheduleState,
} from '@/shared/constants/pages';

const TodoControl = (): React.ReactElement => {
  const toggleEditMode = useControlStore(getToggleEditMode);
  const checkedList = useControlStore(checkedListState);
  const setCheckedList = useControlStore(setCheckedListState);
  const idxOnDate = useControlStore(idxOnDateState);
  const schedule = useScheduleStore(getScheduleState);
  const setSchedule = useScheduleStore(setScheduleState);

  const allChecked = idxOnDate.every(((item, idx) => item === checkedList[idx])) && idxOnDate.length !== 0;
  const allCheck = (e: SyntheticEvent) => {
    setCheckedList((e.target as HTMLInputElement).checked ? [...idxOnDate] : []);

  }
  const changeEditMode = (e: SyntheticEvent) => {
    toggleEditMode((e.target as HTMLInputElement).checked);
  }

  const bulkDone = () => {
    const copyedSchedule = [...schedule];
    for (const idx of checkedList) {
      copyedSchedule[idx].status = true;
    }
    setSchedule(copyedSchedule);
  }

  return (
    <TodoControlContainer>
      <input type="checkbox" id="allCheck" checked={allChecked} onChange={allCheck}/>
      <label htmlFor="allCheck">전체선택</label>
      <button className="done" onClick={bulkDone}/>
      <label className="custom-checkbox edit"><input type="checkbox" onChange={changeEditMode}/><i /></label>
    </TodoControlContainer>
  );
};

export default TodoControl;
