import { ISchedule } from '@/stores/useScheduleStore';
import dayjs from 'dayjs';

export interface ITodoItem {
  date: dayjs.Dayjs;
  idx?: number
  schedule: ISchedule;
  setSchedule?: (scheduleItem: ISchedule, idx?: number) => void;
  submit: (idx?: number, scheduleItem?: ISchedule)=>void;
}
