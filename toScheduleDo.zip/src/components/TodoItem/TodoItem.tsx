import React, { SyntheticEvent, KeyboardEvent } from 'react';
import dayjs from 'dayjs';
import classnames from 'classnames';
import { ITodoItem } from './TodoItem.type';
import { useControlStore } from '@/stores/useControlStore';
import { checkedListState, getEditMode, setCheckedListState } from '@/shared/constants/pages';
import { TodoItemContainer } from './TodoItem.styles';
import { ReactComponent as Strike } from '@/assets/strike.svg';
import { ReactComponent as Delete } from '@/assets/delete.svg';
import { ReactComponent as Submit } from '@/assets/submit.svg';

const TodoItem = ({ date, schedule, setSchedule, submit, idx }: ITodoItem): React.ReactElement => {
  const checkedList = useControlStore(checkedListState);
  const setCheckedList = useControlStore(setCheckedListState);
  const editMode = useControlStore(getEditMode);

  const isChecked = checkedList.includes(idx);
  const toggleCheck = (e: SyntheticEvent) => {
    const checked = (e.target as HTMLInputElement).checked;
    setCheckedList([...checkedList.filter(checkedIndex => checkedIndex !== idx), ...(checked ? [idx] : [])]);
  };

  const setTime = (e : SyntheticEvent) => {
    setSchedule({
      ...schedule,
      date: dayjs(`${date.format('YYYY-MM-DD')} ${(e.target as HTMLInputElement).value}`)
    }, idx)
  }
  const setSubject = (e : SyntheticEvent) => {
    setSchedule({
      ...schedule,
      subject: (e.target as HTMLInputElement).value,
    }, idx);
  }

  const setDone = (e : SyntheticEvent) => {
    setSchedule({
      ...schedule,
      status: !schedule.status,
    }, idx);
  }

  const del = () => {
    if(!confirm('일정을 삭제하시겠습니까?\n삭제된 후에는 되돌릴 수 없습니다.')) return;
    setSchedule(null, idx);
  }

  const onEnter = (e : KeyboardEvent<HTMLInputElement>) => {
    if(e.key === 'Enter') {
      submit(idx)
    }
  }

  return (
    <TodoItemContainer className={classnames({done: schedule.status})}>
      <div className="checkbox-wrapper">
        {idx === undefined ? null :<input type="checkbox" checked={isChecked} onChange={toggleCheck}/>}
      </div>
      <div className="content-wrapper">
        <input type='time' readOnly={idx !== undefined && (!editMode || schedule.status)} value={dayjs(schedule.date).format('HH:mm')} onChange={setTime}/>
        <input type='text' readOnly={idx !== undefined && (!editMode || schedule.status)} value={schedule.subject} onChange={setSubject} onKeyPress={onEnter}/>
      </div>
      <div className="handle-wrapper">
        { idx === undefined || idx === null ? <Submit onClick={()=>submit(idx)}/> : <Strike className={classnames({done: schedule.status})} onClick={setDone}/>}
        {idx === undefined || editMode ? <Delete onClick={del}/> : null}
      </div>
    </TodoItemContainer>
  );
};

export default TodoItem;
