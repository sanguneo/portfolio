import React from 'react';
import styled from '@emotion/styled';

export const TodoItemContainer = styled.li<React.CSSProperties>`
  width: 100%;
  display: flex;
  gap: 10px;
  align-items:center;
  & > div {
    &.checkbox-wrapper {
      width: 20px;
    }
    &.content-wrapper {
      display:flex;
      flex: 1;
      position: relative;
      & > input {
        height: 32px;
        border: 0;
      }
      & > input[type=time] {
        font-size:12px;
        letter-spacing: -0.01em;
        font-family: 'Spoqa Han Sans Neo', 'sans-serif';
        width: 80px;
        &::-webkit-datetime-edit-text {
          letter-spacing: -0.1em;
        }
        &::-webkit-calendar-picker-indicator {
          margin-left: 0;
        }
      }
      & > input[type=text] {
        flex: 1;
        border-bottom: 1px solid #e9e9e9;
        outline:none;
        &:read-only {
          border-bottom:0!important;
        }
        &:focus {
          border-bottom-color: #000000;
        }
      }
    }
    &.handle-wrapper {
      display:flex;
      gap: 10px;
      
      & > svg {
        cursor: pointer;
        opacity: 0.5;
        width: 26px;
        height: 26px;
        &.done {
          opacity: 1;
        }
      }
    }
  }
  &.done {
    & > .content-wrapper {
      &:before {
        position: absolute;
        height: 1px;
        width: 100%;
        top: 50%;
        background-color: black;
        content: '';
        display:block;
      }
    }
  }
`;
