import { IControlStore } from '@/stores/useControlStore';
import { IScheduleStore } from '@/stores/useScheduleStore';

export const getEditMode = (store: IControlStore) => store.editMode;
export const getToggleEditMode = (store: IControlStore) => store.toggleEditMode;
export const dateState = (store: IControlStore) => store.date;
export const setDateState = (store: IControlStore) => store.setDate;
export const checkedListState = (store: IControlStore) => store.checkedList.sort();
export const setCheckedListState = (store: IControlStore) => store.setCheckedList;
export const idxOnDateState = (store: IControlStore) => store.idxOnDate.sort();
export const setIdxOnDateState = (store: IControlStore) => store.setIdxOnDate;

export const getScheduleState = (store: IScheduleStore) => store.schedule.map((item, idx) => ({...item, idx}));
export const setScheduleState = (store: IScheduleStore) => store.setSchedule;
export const manipulateScheduleState = (store: IScheduleStore)=> ({addSchedule: store.addSchedule, removeSchedule: store.removeSchedule, editSchedule: store.editSchedule})
