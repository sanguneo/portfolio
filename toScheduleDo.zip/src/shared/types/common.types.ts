export type Nullable<T> = T | null;
export type TOperation = 'get' | 'post' | 'patch' | 'put' | 'delete';
