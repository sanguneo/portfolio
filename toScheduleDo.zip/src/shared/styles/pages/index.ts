import React from 'react';
import styled from '@emotion/styled';
import { MediaQuery } from '@/shared/styles';

export const HomeContainer = styled.main<React.CSSProperties>`
  display: flex;
  width: 100%;
  height: 100vh;
  gap: 50px;
  padding: 20px;
  ${MediaQuery.mobile} {
    gap: 0;
    flex-direction:column;
    padding: 5px;
  }
  & > div.date-wrapper {
    display: flex;
    width: 60%;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20px;
    gap: 30px;
    ${MediaQuery.mobile} {
      width: calc(100% + 10px);
      padding:20px 5px 5px 5px;
      margin: -5px -5px 30px -5px;
      margin-bottom: 20px;
      box-shadow: 0 3px 4px 0 rgba(225,225,225, 0.7);
    }
  }
  & > div.todo-wrapper {
    display: flex;
    width: 40%;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
    padding: 20px;
    gap: 30px;
    ${MediaQuery.mobile} {
      width: 100%;
      padding:5px;
    }
  }
`;
