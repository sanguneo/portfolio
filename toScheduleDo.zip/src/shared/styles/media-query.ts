const sizes = {
  mobile: 800,
  tablet: 1024,
  desktop: 1024,
};

type TMediaQuery = Record<keyof typeof sizes, string>;

const MediaQuery: TMediaQuery = {
  mobile: `@media screen and (max-width: ${sizes.mobile}px)`,
  tablet: `@media screen and (max-width: ${sizes.tablet}px)`,
  desktop: `@media screen and (min-width: ${sizes.desktop}px)`,
};

export { MediaQuery };
