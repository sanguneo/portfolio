import { GlobalStyles } from '@/shared/styles/global';
import { MediaQuery } from '@/shared/styles/media-query';

export { GlobalStyles, MediaQuery };
