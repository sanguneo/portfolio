import React from 'react';
import { Routes, Route, BrowserRouter } from 'react-router-dom';
import IndexPage from '@/pages/index';

const CustomRouter = (props = {}) => <BrowserRouter>
  <Routes {...props}>
    <Route key="IndexPage" path="/" element={<IndexPage/>} />
  </Routes>
</BrowserRouter>;

export default CustomRouter;
