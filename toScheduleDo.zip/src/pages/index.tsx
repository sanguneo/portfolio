import React from 'react';
import { HomeContainer } from '@/shared/styles/pages';
import Indicator from '@/components/Indicator/Indicator';
import Calendar from '@/components/Calendar/Calendar';
import TodoList from '@/components/TodoList/TodoList';
import TodoControl from '@/components/TodoControl/TodoControl';

const Home = (): React.ReactElement => {

  return (
    <HomeContainer>
      <div className="date-wrapper">
        <Indicator/>
        <Calendar/>
      </div>
      <div className="todo-wrapper">
        <TodoControl />
        <TodoList />
      </div>
    </HomeContainer>
  );
};

export default Home;
