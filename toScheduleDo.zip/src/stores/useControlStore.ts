import create from 'zustand';
import dayjs from 'dayjs';

export interface IControlStore {
  date: dayjs.Dayjs;
  setDate: (date: dayjs.Dayjs) => void;
  editMode: boolean;
  toggleEditMode: (editMode : boolean) => void;
  checkedList: number[];
  setCheckedList: (checkedList:number[]) => void;
  idxOnDate: number[];
  setIdxOnDate: (idxOnDate:number[]) => void;
}

export const useControlStore = create<IControlStore>((set) => ({
  date: dayjs(),
  setDate: (date)=> set({date}),
  editMode: false,
  toggleEditMode: (editMode)=> set({editMode}),
  checkedList: [],
  setCheckedList: (checkedList) => set({checkedList}),
  idxOnDate: [],
  setIdxOnDate: (idxOnDate) => set({idxOnDate}),
}));
