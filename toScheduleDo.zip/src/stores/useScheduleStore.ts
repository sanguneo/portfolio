import dayjs from 'dayjs';
import create from 'zustand';
import { devtools, persist } from 'zustand/middleware'

export interface ISchedule {
  date: string | dayjs.Dayjs;
  subject: string;
  status: boolean; // scheduled, done;
}

export interface IScheduleStore {
  schedule: ISchedule[];
  setSchedule: (schedule: ISchedule[]) => void;
  addSchedule: (scheduleItem: ISchedule) => void;
  removeSchedule: (idx: number) => void;
  editSchedule: (idx: number, scheduleItem: ISchedule) => void;
}

// @ts-ignore
export const useScheduleStore = create<IScheduleStore>(persist((set, get) => ({
  schedule: [],
  setSchedule: (schedule) => set(() => ({ schedule })),
  addSchedule: (scheduleItem) => set(() => ({ schedule: [...get().schedule, scheduleItem] })),
  removeSchedule: (idx) =>  set(() => ({ schedule: get().schedule.filter((_, i) => i !== idx) })),
  editSchedule: (idx, scheduleItem) => set(() => {
    const schedule = [...get().schedule];
    schedule[idx] = Object.assign({}, schedule[idx], scheduleItem);
    return { schedule }
  })
}), { name: 'toScheduleDo', getStorage: () => localStorage, version: 1 }));
