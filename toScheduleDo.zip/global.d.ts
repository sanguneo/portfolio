declare module 'js-cookie';
